package vn.demo.aioverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = 0xFF0B1024.toInt()
    private val panel = 0xFF171D3B.toInt()
    private val accent = 0xFF7C3AED.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 28, 22, 22)
        setBackgroundColor(bg)
    }

    private fun text(value: String, size: Float = 16f, color: Int = -1) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            setPadding(8, 10, 8, 10)
        }

    private fun button(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun card(title: String, subtitle: String): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 8, 14, 8)
            setBackgroundColor(panel)
            addView(text(title, 17f))
            addView(text(subtitle, 13f, 0xFFB9C2E8.toInt()))
        }

    private fun showHome() {
        val root = base()
        root.addView(text("AI ASSISTANT PRO", 25f))
        root.addView(text("Trợ lý nổi • Tự động hóa có kiểm soát", 14f, 0xFFB9C2E8.toInt()))
        root.addView(card("Trợ lý AI", "Sẵn sàng nhận lệnh. Bản này là khung giao diện, chưa kết nối mô hình AI."))
        root.addView(button("Bật menu nổi") { requestOverlayAndStart() })
        root.addView(button("Kho Email") { showVault() })
        root.addView(button("Cấp quyền Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Cài đặt quyền hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        })
        root.addView(button("Ứng dụng đã cài") { showApps() })
        root.addView(button("Nhật ký & quyền riêng tư") { showLogs() })
        root.addView(text("Lưu ý: Email đang hiển thị là dữ liệu mẫu. Chưa có API email hoặc AI thật được cấu hình.", 12f, 0xFFFFD166.toInt()))
        setContentView(root)
    }

    private fun requestOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            Toast.makeText(this, "Hãy cấp quyền hiển thị nổi rồi quay lại bật menu.", Toast.LENGTH_LONG).show()
        } else {
            startForegroundService(Intent(this, FloatingMenuService::class.java))
            Toast.makeText(this, "Đã bật menu nổi.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showVault() {
        val root = base()
        root.addView(text("KHO EMAIL", 24f))
        root.addView(text("Danh sách minh họa — chưa kết nối nhà cung cấp email.", 13f, 0xFFFFD166.toInt()))
        listOf(
            "demo-inbox-01@example.test" to "Chưa kết nối",
            "demo-inbox-02@example.test" to "Chưa kết nối",
            "demo-inbox-03@example.test" to "Chưa kết nối"
        ).forEach { (email, status) ->
            val row = card(email, status)
            row.addView(button("Sao chép") {
                val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clip.setPrimaryClip(android.content.ClipData.newPlainText("Email", email))
                Toast.makeText(this, "Đã sao chép địa chỉ mẫu", Toast.LENGTH_SHORT).show()
            })
            root.addView(row)
        }
        root.addView(button("Đọc OTP") {
            Toast.makeText(this, "Cần kết nối hộp thư được bạn cấp quyền trước.", Toast.LENGTH_LONG).show()
        })
        root.addView(button("Quay lại") { showHome() })
        setContentView(root)
    }

    private fun showApps() {
        val root = base()
        root.addView(text("ỨNG DỤNG", 24f))
        val pm = packageManager
        val apps = pm.getInstalledApplications(0).filter {
            pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != packageName
        }.take(30)
        apps.forEach { info ->
            val label = pm.getApplicationLabel(info).toString()
            root.addView(button(label) {
                startActivity(pm.getLaunchIntentForPackage(info.packageName))
            })
        }
        root.addView(button("Quay lại") { showHome() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun showLogs() {
        val root = base()
        root.addView(text("NHẬT KÝ & QUYỀN RIÊNG TƯ", 22f))
        root.addView(text("Bản thử nghiệm không gửi dữ liệu ra máy chủ. Quyền Accessibility chỉ nên bật khi bạn hiểu rõ mục đích và có thể tắt bất cứ lúc nào."))
        root.addView(button("Mở cài đặt Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Quay lại") { showHome() })
        setContentView(root)
    }
}
