package vn.demo.aioverlay

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AssistantAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Chưa tự thao tác. Bản đầu chỉ khai báo điểm tích hợp và chờ lệnh có xác nhận.
    }
    override fun onInterrupt() {}
}
