package vn.demo.aioverlay

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*

class FloatingMenuService : Service() {
    private var windowManager: WindowManager? = null
    private var bubble: View? = null
    private var expanded = false
    private val channelId = "ai_overlay_status"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("AI Assistant")
                .setContentText("Menu nổi đang hoạt động")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        else Notification.Builder(this).setContentTitle("AI Assistant")
            .setContentText("Menu nổi đang hoạt động")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        startForeground(7, notification)
        showBubble()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Trạng thái menu nổi",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }

        val button = Button(this).apply {
            text = "AI"
            textSize = 16f
            setOnClickListener { togglePanel(params) }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                override fun onTouch(v: View, event: MotionEvent): Boolean {
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = event.rawX; downY = event.rawY
                            startX = params.x; startY = params.y
                            return false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params.x = startX + (downX - event.rawX).toInt()
                            params.y = startY + (event.rawY - downY).toInt()
                            windowManager?.updateViewLayout(v, params)
                            return true
                        }
                    }
                    return false
                }
            })
        }
        bubble = button
        windowManager?.addView(button, params)
    }

    private fun togglePanel(anchor: WindowManager.LayoutParams) {
        if (expanded) {
            (bubble as? Button)?.text = "AI"
            expanded = false
            return
        }
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF171D3B.toInt())
            addView(TextView(context).apply {
                text = "TRỢ LÝ AI"; textSize = 18f; setTextColor(-1)
            })
            addView(TextView(context).apply {
                text = "Bản thử nghiệm • AI chưa kết nối"; setTextColor(0xFFCDD5FF.toInt())
            })
            addView(Button(context).apply { text = "Mở ứng dụng"; setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage(packageName)
                i?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); if (i != null) startActivity(i)
            }})
            addView(Button(context).apply { text = "Thu nhỏ"; setOnClickListener {
                (bubble as? Button)?.text = "AI"; expanded = false
                windowManager?.removeView(this@apply.parent as? View)
            }})
            addView(Button(context).apply { text = "Dừng ngay"; setOnClickListener {
                stopSelf()
            }})
        }
        // Keep the first release safe and simple: expand the floating control into a dialog-like panel.
        val dialog = android.app.AlertDialog.Builder(this)
            .setView(menu).create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.show()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        expanded = true
        dialog.setOnDismissListener { expanded = false; (bubble as? Button)?.text = "AI" }
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
